@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package slimeknights.tconstruct.gadgets;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;

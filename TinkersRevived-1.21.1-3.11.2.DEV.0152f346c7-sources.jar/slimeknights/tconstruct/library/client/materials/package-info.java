@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package slimeknights.tconstruct.library.client.materials;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;
